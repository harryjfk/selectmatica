<?php

namespace Store\RestBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Symfony\HttpFoundation\Response;
class DefaultController extends Controller
{
	 private static function CallAPI($method, $url,$user,$pass, $data = false)
    {
        $curl = curl_init();

        switch ($method)
        {
            case "POST":
                curl_setopt($curl, CURLOPT_POST, 1);

                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            case "PUT":
                curl_setopt($curl, CURLOPT_PUT, 1);
                break;
            default:
                if ($data)
                    $url = sprintf("%s?%s", $url, http_build_query($data));
        }

        // Optional Authentication:
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curl, CURLOPT_USERPWD, $user.":".$pass);

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

        $result = curl_exec($curl);

        curl_close($curl);

        return $result;
    }

    public static  function GetRest($controller,$url)
    {
        $url =   $controller->container->getParameter('default_api_url').$url;
        $user=        $controller->container->getParameter('default_api_username');
        $pass=         $controller->container->getParameter('default_api_password');
       return  json_decode(DefaultController::CallAPI('GET',$url,$user,$pass,false));
    }
    public function indexAction()
    {
	  echo json_encode( DefaultController::GetRest($this,"/articulos?web=true&baja=false"));

		// $em->getRepository('StoreRestBundle:Producto')->findAll();
		//echo $t->count;
        /*return $this->render('StoreRestBundle:Default:index.html.twig', array('name' => $name));*/
    }

}
