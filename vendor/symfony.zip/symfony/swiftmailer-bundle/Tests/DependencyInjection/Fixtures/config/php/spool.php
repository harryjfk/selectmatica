<?php
$container->loadFromExtension('swiftmailer', array(
    'spool' => true
));
