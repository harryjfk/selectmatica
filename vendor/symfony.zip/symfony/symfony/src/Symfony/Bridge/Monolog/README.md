Monolog Bridge
==============

Provides integration for Monolog with various Symfony components.

Resources
---------

You can run the unit tests with the following command:

    $ cd path/to/Symfony/Bridge/Monolog/
    $ composer install
    $ phpunit
