Twig Bridge
===========

Provides integration for [Twig](http://twig.sensiolabs.org/) with various
Symfony components.

Resources
---------

If you want to run the unit tests, install dev dependencies before
running PHPUnit:

    $ cd path/to/Symfony/Bridge/Twig/
    $ composer install
    $ phpunit
