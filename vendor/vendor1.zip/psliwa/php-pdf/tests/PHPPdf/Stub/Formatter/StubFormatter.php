<?php

namespace PHPPdf\Stub\Formatter;

use PHPPdf\Core\Formatter\BaseFormatter;

class StubFormatter extends BaseFormatter
{
    public function format(\PHPPdf\Core\Node\Node $node, \PHPPdf\Core\Document $document)
    {
    }
}