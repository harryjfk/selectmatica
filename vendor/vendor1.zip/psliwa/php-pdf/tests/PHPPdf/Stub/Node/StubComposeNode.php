<?php

namespace PHPPdf\Stub\Node;

use PHPPdf\Core\Node\Container;

class StubComposeNode extends Container
{
}