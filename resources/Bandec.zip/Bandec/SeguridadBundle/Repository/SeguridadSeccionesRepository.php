<?php

namespace Bandec\SeguridadBundle\Repository;

use Doctrine\ORM\EntityRepository;

class SeguridadSeccionesRepository extends EntityRepository {

}
