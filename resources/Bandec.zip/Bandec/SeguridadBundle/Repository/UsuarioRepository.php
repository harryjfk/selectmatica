<?php

namespace Bandec\SeguridadBundle\Repository;

use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\User\UserProviderInterface;
//use Symfony\Component\Security\Core\Exception\UsernameNotFoundException;
use Symfony\Component\Security\Core\Exception\UnsupportedUserException;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\NoResultException;
use Bandec\SeguridadBundle\Entity\Usuario;

class UsuarioRepository extends EntityRepository implements UserProviderInterface {

    public function queryResult($params = array()) {
        
        $cond = array();
        $parameters = array();
        
        if($params['nombre'])
        {
            $cond[] = '(u.nombre like :nombre or u.primerApellido like :nombre or u.segundoApellido like :nombre)';
            $parameters['nombre'] = '%'.$params['nombre'].'%';
        }
                
        if($params['username'])
        {
            $cond[] = 'u.username like :username';
            $parameters['username'] = '%'.$params['username'].'%';
        }
        
        if($params['email'])
        {
            $cond[] = 'u.email like :email';
            $parameters['email'] = '%'.$params['email'].'%';
        }
        
        $hasParameters = count($cond) > 0;
        $q = $hasParameters ? 'where '.implode( 'and', $cond ) : '';
        $query = $this->getEntityManager()->createQuery("select u, c
                from SeguridadBundle:Usuario u 
                left join u.idcargo as c                
                $q order by u.nombre asc");
        if($hasParameters)
            $query->setParameters ($parameters);
        
        return $query;
    }

    public function loadUserByUsername($username) {
       
        $q = $this
                ->createQueryBuilder('u')
                ->select('u, gu, r')
                ->where('u.username = :username OR u.email = :email')
                ->join('u.grupoid', 'gu')
                ->join('gu.rol', 'r')
                ->setParameter('username', $username)
                ->setParameter('email', $username)
                ->getQuery()
        ;

        try {
            $user = $q->getSingleResult();
        } catch (NoResultException $e) {
            //devuelvo una instancia del usuario vacía si no se ha encontrado para que no de error
            $user = new Usuario();
        }

        return $user;
    }

    public function refreshUser(UserInterface $user) {
        $class = get_class($user);
        if (!$this->supportsClass($class)) {
            throw new UnsupportedUserException(sprintf('La instancia de "%s" no está soportada.', $class));
        }

        return $this->loadUserByUsername($user->getUsername());
    }

    public function supportsClass($class) {
        return $this->getEntityName() === $class || is_subclass_of($class, $this->getEntityName());
    }

}
