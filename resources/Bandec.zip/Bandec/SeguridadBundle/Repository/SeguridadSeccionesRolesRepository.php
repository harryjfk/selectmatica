<?php

namespace Bandec\SeguridadBundle\Repository;

use Doctrine\ORM\EntityRepository;

class SeguridadSeccionesRolesRepository extends EntityRepository {

}
