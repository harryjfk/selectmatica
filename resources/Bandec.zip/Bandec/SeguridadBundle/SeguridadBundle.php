<?php

namespace Bandec\SeguridadBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SeguridadBundle extends Bundle
{
}
