<?php

namespace Store\StoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class StoreStoreBundle extends Bundle
{
}
