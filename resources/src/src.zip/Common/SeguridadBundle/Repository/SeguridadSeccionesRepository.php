<?php

namespace Common\SeguridadBundle\Repository;

use Doctrine\ORM\EntityRepository;

class SeguridadSeccionesRepository extends EntityRepository {

}
