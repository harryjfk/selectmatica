<?php

namespace Common\SeguridadBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CommonSeguridadBundle extends Bundle
{
}
