<?php

namespace Common\AdminBaseBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CommonAdminBaseBundle extends Bundle
{
}
