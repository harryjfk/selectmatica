<?php

namespace Common\BaseAppBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CommonBaseAppBundle extends Bundle
{
}
