<?php

namespace Common\SeguridadBundle\Repository;

use Doctrine\ORM\EntityRepository;

class SeguridadSeccionesRolesRepository extends EntityRepository {

}
