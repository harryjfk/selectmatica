<?php

namespace Store\RestBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class StoreRestBundle extends Bundle
{
}
